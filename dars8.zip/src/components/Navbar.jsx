import { Link } from "react-router-dom";
import { useContext } from "react";
import { GlobalContext } from "../context/GlobalContext";

function Navbar() {
  const { counter } = useContext(GlobalContext);

  return (
    <div className="navbar bg-base-100">
      <div className="max-container">
        <div className="flex-1">
          <Link to="/" className="btn btn-ghost text-xl">
            daisyUI
          </Link>
        </div>
        <div>
          <h3 className="mr-[100px]">counter: {counter}</h3>
        </div>
        <div className="flex items-center gap-3">
          <p>Welcome, websites</p>
          <button className="btn btn-secondary btn-sm">Logout</button>
        </div>
      </div>
    </div>
  );
}

export default Navbar;
